METALES LA BASE - PROYECTO ANDROID

Este proyecto convierte la versión v2 local en una aplicación Android instalable.

NO requiere servidor ni Supabase. Los datos siguen guardándose localmente en el teléfono.

Compilación online:
1. Subir este proyecto a un repositorio de GitHub.
2. Ir a la pestaña Actions.
3. Ejecutar el workflow "Build METALES LA BASE APK".
4. Descargar el APK generado desde los Artifacts.

La aplicación se llama METALES LA BASE y usa el identificador com.metaleslabase.caja.
